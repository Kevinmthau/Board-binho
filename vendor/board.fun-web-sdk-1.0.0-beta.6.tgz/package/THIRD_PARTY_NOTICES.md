# Third-Party Notices

The `@board.fun/web-sdk` npm package has **no third-party runtime dependencies** of
its own. It is a TypeScript wrapper over the JavaScript bridges the Board
OS injects into the WebView, and ships nothing but its own compiled output.

The on-device runtime the SDK talks to — the Board Browser host and the Board
touch pipeline — includes third-party components governed by their own licenses.
This file collects the notices required by those licenses, even though those
components are **not** redistributed inside this npm package.

---

## TensorFlow Lite

The Board touch pipeline performs on-device glyph (Piece) recognition using
**TensorFlow Lite**, which runs inside the Board Browser host runtime on the
device — not in this npm package or in your game. It is listed here because the
SDK surfaces its output (Piece contacts) to games.

TensorFlow Lite is part of the TensorFlow project:

```
Copyright 2019 The TensorFlow Authors. All rights reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
```

The full Apache License 2.0 text is available at the URL above. TensorFlow and
TensorFlow Lite are trademarks of Google LLC.

---

## Disclosure scope

This notice covers third-party components whose licenses require attribution or
notice redistribution. It is limited to components that ship with, or are
directly exercised by, the Board Web SDK and the on-device runtime it depends on.
`@board.fun/web-sdk` itself is distributed under the Developer Terms of Use,
published at https://docs.dev.board.fun/more/license.
