# Changelog

All notable changes to the Board Web SDK are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0-beta.6] - 2026-06-12

### Changed

- README: point to `@board.fun/create-game` for scaffolding new projects.

## [1.0.0-beta.5] - 2026-06-11

### Changed

- README: point to `@board.fun/web-pack` for packaging and deploy.

## [1.0.0-beta.4] - 2026-06-11

### Fixed

- Pause menu results are now delivered reliably to all apps.
- `BoardPauseResult.action` now matches the documented action names.

## [1.0.0-beta.3] - 2026-06-02

### Changed

- Trim published package metadata.

## [1.0.0-beta.2] - 2026-06-02

### Changed

- Update the reference to the license location.

## [1.0.0-beta.1] - 2026-06-02

First public **beta** of the Board Web SDK. Capability parity with the Board
Unity SDK, exposing the Board platform API surface to web games through the
`Board` namespace injected into the Board WebView by the host OS.

> **This is a beta.** It has had only limited testing on real hardware — expect
> rough edges, and please report anything you hit. The public `Board.*` API is
> append-only and stable in intent, but details may still change before the
> `1.0.0` release.

Supports:

- **Touch & Piece input** — per-frame contact snapshots with Glyph identity,
  position, orientation, lifecycle phase, and hand-presence.
- **Session & player management** — OS-owned roster via the player selector,
  profiles and guests, the active system profile, and the profile switcher
  overlay.
- **Save game management** — create, load, list, and update save games, plus
  removing the game's players from a save (the active profile or all of the
  game's players); the OS deletes a save once no players remain. Includes cover
  images and per-app storage limits.
- **Player avatars** — load player avatar images as data URIs.
- **System pause overlay** — a game-defined pause menu with custom buttons and
  live audio-track controls, plus result polling.

For the full API reference, guides, and setup, see
[docs.dev.board.fun](https://docs.dev.board.fun/).

### Compatibility

- **Board OS minimum:** 1.10.0 or newer.
- **Node 18+** for the build toolchain.
- **Runtime:** arm64-v8a Board devices.
- ESM-only package — consumed by any modern ESM bundler (Vite, webpack 5,
  esbuild, rollup, Parcel).

[1.0.0-beta.6]: https://docs.dev.board.fun/more/changelog
[1.0.0-beta.5]: https://docs.dev.board.fun/more/changelog
[1.0.0-beta.4]: https://docs.dev.board.fun/more/changelog
[1.0.0-beta.3]: https://docs.dev.board.fun/more/changelog
[1.0.0-beta.2]: https://docs.dev.board.fun/more/changelog
[1.0.0-beta.1]: https://docs.dev.board.fun/more/changelog
