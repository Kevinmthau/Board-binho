# @board.fun/web-sdk

Build web games for Board, the tabletop gaming platform with physical piece tracking.

The Board Web SDK is a TypeScript wrapper over the JavaScript bridges injected into
the Board WebView by the host OS. It exposes APIs for touch and Piece input,
multiplayer sessions, save games, player avatars, and the system pause menu.

## Install

Starting fresh? `npm create @board.fun/game my-game` scaffolds a ready-to-pack
project (add `-- --template showcase` for a full working reference) — see
`@board.fun/create-game`. For an existing project:

```bash
npm install @board.fun/web-sdk
```

The package is ESM-only and works with any modern ESM bundler (e.g. Vite, webpack 5,
esbuild, rollup, Parcel).

If you have been granted access to the source repository, you can also install it
directly with npm's `github:<owner>/<repo>` shorthand; the owner/repo coordinate is
provided with your access grant.

## Requirements

- Node 18+ for the build toolchain
- Any modern ESM-compatible bundler (e.g. Vite, webpack 5, esbuild, rollup, Parcel)
- A Board device for runtime; in a normal browser the SDK loads, but device calls
  must be gated on `Board.isOnDevice`

## Documentation

The [quick start](https://docs.dev.board.fun/web/getting-started/quick-start),
[guides](https://docs.dev.board.fun/guides/), and full
[API reference](https://docs.dev.board.fun/web/reference/api) live in the developer
docs at https://docs.dev.board.fun/. The developer portal at https://dev.board.fun/
has the downloads (e.g. Piece Set Models, the `board-connect` CLI).

To get a built game onto a Board, pack it with `@board.fun/web-pack` and install it
with Board Connect; the
[Build & Deploy guide](https://docs.dev.board.fun/web/getting-started/build-and-deploy)
walks through the full flow.

## License

Proprietary, governed by the Developer Terms of Use, published at
https://docs.dev.board.fun/more/license.
