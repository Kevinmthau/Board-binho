# Board Web SDK — Consumer Guide

You're reading this because `@board.fun/web-sdk` is a dependency of this project. This file tells your coding agent (Claude, Codex, Cursor, Gemini CLI, or any other) — and any human who reads it — how to use the SDK to build a working Board web game. (Claude Code reads the sibling `CLAUDE.md`, which simply imports this file, so both point at the same content.)

The full human developer docs live at https://docs.dev.board.fun/. This guide is the agent-facing quick reference; the docs site is the authoritative long form.

## What is Board?

Board is a 23.8" 1080p landscape touch-display console (MediaTek Genio 700, 4 GB RAM, WiFi 6) designed for tabletop play. Beyond raw finger touches, Board's capacitive sensor recognizes the conductive **Glyph** pattern on the base of each physical **Piece** in a **Piece Set**, giving games per-piece identity, position, orientation, and a hand-presence signal. A web game runs inside a WebView on the device; the OS injects JavaScript bridges that this SDK wraps. The SDK exposes that touch and piece input plus the OS-level session, save, avatar, and pause services.

Vocabulary, always capitalized:

| Term          | Definition                                                                         |
| ------------- | --------------------------------------------------------------------------------- |
| **Piece**     | A physical game piece with a Glyph pattern on its base.                            |
| **Piece Set** | A collection of Pieces for a specific game.                                        |
| **Glyph**     | The conductive pattern on a Piece's base detected by the touch sensor.            |

## Install & Project Setup

The package is published as `@board.fun/web-sdk` and is **ESM-only**. It works with any modern ESM bundler (Vite, webpack 5, esbuild, rollup, Parcel).

For a new project, scaffold with `npm create @board.fun/game my-game` (add `-- --template showcase` for a working reference exercising every SDK domain) — it pre-wires the relative base path, pack scripts, and Piece Set Model placeholder, and ships an agent guide in the project root. For an existing project:

```bash
npm install @board.fun/web-sdk
```

```ts
import { Board, BoardContactType } from "@board.fun/web-sdk";
```

Build your game with a bundler and set the bundler's **base path to `'./'`** so the bundle uses relative asset URLs — the device serves the app from a bundle root, not from a site root. For Vite:

```ts
// vite.config.ts
export default { base: "./" };
```

Off the device (local dev, CI, a normal browser), `Board.isOnDevice` is `false` and any service-backed API call throws. Gate all Board code behind `Board.isOnDevice` so the same bundle runs both on a Board and in a regular browser for preview or testing.

## Public API Quick Reference

Everything hangs off the frozen `Board` object. Each domain is also exported as a named ES module export, so you can import a single domain directly.

```ts
import { Board } from "@board.fun/web-sdk";
// or import individual domains:
import { input, session, save, avatar, pause, application } from "@board.fun/web-sdk";
```

| Domain              | Entry points                                                                                                                                                                                                                                                                                                       |
| ------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `Board.input`       | `subscribe(cb)`, `unsubscribe(cb)`, `getContacts()`, `getContactsByType(type)`, getter `isSubscribed`                                                                                                                                                                                                              |
| `Board.session`     | `getPlayers()`, `getPlayerCount()`, `getActiveProfile()`, `addGuest(sessionId)`, `removePlayer(sessionId)`, `resetPlayers()`, `setAIPlayerTypes(types)`, `presentAddPlayer(aiTypeIndices?)`, `presentReplacePlayer(sessionId, aiTypeIndices?)`, `isReady()`, `areServicesReady()`                                    |
| `Board.save`        | `create(...)`, `load(id)`, `list()`, `update(...)`, `removePlayersFromSave(id)`, `removeActiveProfileFromSave(id)`, `loadCoverImage(id)`, `getAppStorageInfo()`, `getUniquePlayers(saves)`, `getMaxDataSize()`, `getMaxAppStorageSize()`, `getMaxDescriptionLength()`                                  |
| `Board.avatar`      | `loadPNG(avatarId)`, `getDefault()`, `forPlayer(player)`, `clearCache()`                                                                                                                                                                                                                                           |
| `Board.pause`       | `setContext(ctx)`, `updateContext(partial)`, `clearContext()`, `onResult(cb)`, `pollResult()`                                                                                                                                                                                                                      |
| `Board.application` | `quit()`, `showProfileSwitcher()`, `hideProfileSwitcher()`                                                                                                                                                                                                                                                         |
| getters             | `Board.isOnDevice` (boolean), `Board.sdkVersion` (string, informational only)                                                                                                                                                                                                                                      |

Named ES-module exports: `Board`, `input`, `session`, `save`, `avatar`, `pause`, `application`, `isBoardDevice`, `SDK_VERSION`; enums `BoardContactType`, `BoardContactPhase`, `BoardPlayerType`; interfaces/types `BoardContact`, `BoardPlayer`, `BoardAIPlayerType`, `BoardAppStorageInfo`, `BoardSaveGamePlayer`, `BoardSaveGameMetadata`, `BoardPauseButton`, `BoardPauseAudioTrack`, `BoardPauseAudioTrackResult`, `BoardPauseContext`, `BoardPauseResult`, `TouchFrameCallback`. (`BoardPlayerType` is exported from the package root as a value but `Board.input`/`session`/etc. are the runtime entry points.)

`BoardContact` fields: `contactId`, `x`, `y`, `orientation` (degrees, meaningful for Glyph contacts), `type` (`BoardContactType` — `Finger` / `Glyph` / `Blob`), `phase` (`BoardContactPhase` — `Began` / `Moved` / `Stationary` / `Ended` / `Canceled`), `glyphId` (0 = finger, 1+ = piece type), `isTouched` (a hand is physically touching the piece).

Full reference: https://docs.dev.board.fun/.

## Critical Constraints

- **Touch coordinates are Y-down with no flip.** `x` is display pixels from the left edge, `y` from the top edge. Don't add coordinate transforms — the DOM and canvas conventions already match the platform.
- **Filter pieces by `glyphId`, not by `type`.** `type` only tells you Finger vs Glyph vs Blob. The specific Piece is in `glyphId`. A finger has `glyphId === 0`; pieces are `1+`. The SDK never names pieces — Glyph IDs are integers and the taxonomy is game-specific, so your game owns its own name table.
- **Contacts are per-frame snapshots; the game diffs them.** `subscribe(cb)` fires every inference frame (~60fps) with the full set of currently-active contacts. A piece sitting still reappears every frame with `phase` = `Stationary` until it is lifted (`phase` = `Ended`). To detect discrete edges (tap-down, tap-up, piece-placed, piece-lifted), keep your own previous-frame map keyed by `contactId` and diff it yourself.
- **Await every Promise and handle rejection.** Save, avatar, and player-selector calls are async. When a backing service is unavailable they reject, and an unhandled rejection will surface as an error — wrap them in `try`/`catch` (or `.catch`) and degrade gracefully.
- **Gate on `Board.isOnDevice`.** Every service-backed call throws off-device. Where a feature needs the save/overlay services connected, additionally gate on `Board.session.areServicesReady()`.
- **The touch ML model is obtained out of band, and every bundle ships one.** The SDK ships no model — the correct one depends on which Piece Set your game uses. Download it from the developer portal at https://dev.board.fun, place the file in your project (e.g. `public/model.tflite` so the bundler copies it into `dist/`), and `web-pack` picks it up (or pass its path with `--model`). A model is **required** — `web-pack` rejects a bundle with none. The model is **never** bundled by tooling and **never** fetched at runtime.

## Common Patterns

### Touch subscribe + frame diffing

```ts
import { Board, BoardContactPhase } from "@board.fun/web-sdk";

const prev = new Map<number, boolean>(); // contactId -> isTouched last frame

function onFrame(contacts: ReadonlyArray<import("@board.fun/web-sdk").BoardContact>) {
  const seen = new Set<number>();
  for (const c of contacts) {
    seen.add(c.contactId);
    const wasTouched = prev.get(c.contactId) ?? false;
    if (c.isTouched && !wasTouched) {
      // rising edge: the user just pressed down on this contact
    } else if (!c.isTouched && wasTouched) {
      // falling edge: tap-up / hand released
    }
    if (c.phase === BoardContactPhase.Ended) {
      // last frame this contact appears in (piece lifted / finger up)
    }
    prev.set(c.contactId, c.isTouched);
  }
  for (const id of [...prev.keys()]) if (!seen.has(id)) prev.delete(id);
}

if (Board.isOnDevice) {
  Board.input.subscribe(onFrame);
}
// later: Board.input.unsubscribe(onFrame);
```

### Filtering by Glyph ID

Keep the IDs your game cares about in a game-side constant table. Never name pieces in shared/library code.

```ts
import { Board } from "@board.fun/web-sdk";

const PIECE_PLAYER = 12;
const PIECE_TARGET = 45;

Board.input.subscribe((contacts) => {
  for (const c of contacts) {
    if (c.glyphId === 0) continue; // finger, not a piece
    switch (c.glyphId) {
      case PIECE_PLAYER:
        // ...
        break;
      case PIECE_TARGET:
        // ...
        break;
    }
  }
});
```

### Save CRUD with a generated cover image

The roster on a save is OS-owned; the game writes only its own opaque payload.

```ts
import { Board } from "@board.fun/web-sdk";

async function saveGame(state: Uint8Array, playedMs: number) {
  if (!Board.isOnDevice) return;
  try {
    const meta = await Board.save.create("Round 3", state, playedMs, "1.0.0");
    return meta; // BoardSaveGameMetadata: id, players[], hasCoverImage, ...
  } catch (err) {
    // service unavailable / quota exceeded — surface to the player
    console.error("save failed", err);
  }
}

async function listAndLoad() {
  const saves = await Board.save.list();
  if (saves.length === 0) return;
  const data = await Board.save.load(saves[0].id); // Uint8Array
  if (saves[0].hasCoverImage) {
    const dataUri = await Board.save.loadCoverImage(saves[0].id);
    // <img src={dataUri}>
  }
  // There is no direct save delete (parity with the Unity SDK). A game removes
  // its own players from a save; the OS deletes the save once none remain:
  //   await Board.save.removePlayersFromSave(saves[0].id);   // all of the game's players
  //   await Board.save.removeActiveProfileFromSave(saves[0].id); // just the active profile
}
```

### Avatar data URI

Avatars are immutable per id and cached after first load; concurrent loads of the same id coalesce.

```ts
import { Board } from "@board.fun/web-sdk";

for (const player of Board.session.getPlayers()) {
  const dataUri = await Board.avatar.forPlayer(player); // "data:image/png;base64,..."
  // img.src = dataUri;
}
// Board.avatar.getDefault() for the default avatar; Board.avatar.clearCache() to drop the cache.
```

### Pause: setContext + onResult

The OS owns the system menu button and shows/hides it across the lifecycle. The game supplies the context (so the button has something to open) and reads results. Set the context early, before the user can open the menu. Omit keys you don't have rather than serializing empty defaults.

```ts
import { Board } from "@board.fun/web-sdk";

if (Board.isOnDevice) {
  Board.pause.setContext({
    gameName: "My Game",
    offerSaveOption: true,
    customButtons: [{ id: "restart", title: "Restart", icon: "circulararrow" }],
    audioTracks: [{ id: "music", name: "Music", value: 75 }],
  });

  const unsubscribe = Board.pause.onResult((result) => {
    switch (result.action) {
      case "resume":
        break;
      case "quit":
        Board.application.quit();
        break;
      case "save_and_quit":
        // write your save, then quit
        break;
      case "custom_button":
        if (result.customButtonId === "restart") {
          /* restart */
        }
        break;
    }
    // result.audioTracks carries any slider changes the user made.
  });
  // call unsubscribe() to stop listening. (pollResult() is a legacy alternative.)
}
```

### Off-device guard

```ts
import { Board } from "@board.fun/web-sdk";

if (!Board.isOnDevice) {
  // running in a normal browser — wire mouse/keyboard fallback for preview
  wireDevFallback();
} else {
  startBoardGame();
}
```

## Build & Deploy

The agent dev loop is: **bundle → pack → install/launch/observe**.

1. **Bundle.** Build your game with your bundler (e.g. `vite build` → `dist/`), with `base: './'`.
2. **Pack.** Run `web-pack` over the built output to produce an installable bundle:

   ```bash
   web-pack dist --package-id fun.board.example --name "My Game" --model model.tflite
   ```

   `web-pack` writes a `<appId>.webapp.zip` and a generated manifest. The `appId` is a random UUID minted once and persisted to `board.config.json`; **commit `board.config.json`** so the same `appId` (which scopes your saves/profiles) travels with the project across machines and checkouts. A touch model is **required**: keep `model.tflite` in your build output (e.g. `public/`) so `web-pack` picks it up, or pass its path with `--model`. The model is obtained out of band from the developer portal at https://dev.board.fun, and is never fetched or vendored by the packer.

3. **Install, launch, observe** with the `board-connect` CLI (install it from `dev.board.fun/connect/install`):

   ```bash
   board-connect pair <host>                              # tap Approve on the device (once)
   board-connect install <appId>.webapp.zip --launch
   board-connect logs <appId>                             # observe the app's output
   board-connect screenshot --out shot.png                # verify visually
   ```

   `<host>` is the Board's address (shown on the device under its system settings); `board-connect ls` discovers Boards on your LAN. Pairing saves that Board as the default, so later commands need no address (`-b <host>` overrides). The `logs`/`launch`/`remove` id for a web app is the **appId UUID** from `board.config.json`, not the package id.

**Board OS minimum:** 1.10.0 or newer. Confirm the device meets it with `board-connect capabilities` rather than branching on a version number in your game. If the first install reports the host unavailable, foreground the Board Browser on the device once and retry.

## Forward & Backward Compatibility

The public `Board.*` API is **append-only**: namespaces, methods, fields, and enum values are never removed or renamed once shipped. A game built against an older SDK keeps working on newer devices, and a newer SDK keeps working on older ones.

- **Never gate behavior on a version number.** There is no games-visible bridge or OS version, by design. `Board.sdkVersion` reports which SDK build the game bundled and is **informational only** (logging, bug reports) — never a feature gate.
- **New OS capabilities degrade gracefully via in-bridge capability checks.** The OS bridge capability-checks each service and degrades when a capability is missing, rather than exposing a version for games to branch on.
- **Gate on `Board.isOnDevice`** to tell a real device from a dev browser, and on `Board.session.areServicesReady()` where a feature needs the save/overlay services connected — never on a version number.

This matches the Board Unity SDK, which also exposes no bridge-version number.

## What NOT to Do

- Don't version-gate. No game logic should branch on `Board.sdkVersion` or any bridge/OS version. Gate on `Board.isOnDevice` (and `areServicesReady()`).
- Don't bundle or fetch the touch model. It is obtained out of band and passed to `web-pack`; tooling never vendors it and the app never downloads it at runtime.
- Don't mutate the roster directly. Players are added/removed/replaced only through the OS selector (`presentAddPlayer` / `presentReplacePlayer`) or cleared wholesale with `resetPlayers()`. A game can't silently change who's playing.
- Don't expect a direct save delete — there is none, by design (parity with the Unity SDK). A game removes its own players from a save (`removePlayersFromSave(id)`, or `removeActiveProfileFromSave(id)` for just the active profile); the OS deletes the save once no players remain.
- Don't add coordinate transforms. Coordinates are already display-pixel Y-down with no flip.
- Don't distinguish pieces by `type`. Use `glyphId`. Don't bake piece names into the SDK layer or any shared library — Glyph taxonomies belong to the game.
- Don't serialize empty defaults into the pause context. Omit absent keys; an empty `gameId` is rejected by the host and leaves the pause button with nothing to open.
- Don't call service-backed APIs off-device or before services are ready — they throw or reject. Guard them.
- Don't hardcode user-visible strings if your app has a localization/resource mechanism — keep them in that layer.
- Don't use `get_tree().quit()`-style hard exits or `window.close()`. Use `Board.application.quit()` so the user lands cleanly back in the launcher.

## Where to Find More

- Full developer docs (authoritative, human-facing): https://docs.dev.board.fun/
- Developer portal (downloads, models, account): https://dev.board.fun/
- Package README and changelog ship with `@board.fun/web-sdk`.
